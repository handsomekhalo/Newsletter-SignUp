const express = require("express");
/*const https = require("https");*/
const bodyParser = require("body-parser");
const request = require("request");
const { url } = require("inspector");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

//use to access local css and images
app.use(express.static("public"));

/*app.post("/", function (req, res) {
  const firstName = req.body.fName;
  const lName = req.body.lName;
  const email = req.body.email;

  const data = {
    members: [
      {
        email_address: email,
        status: "subscribed",
        merge_fields: { FNAME: firstName, LNAME: lName },
            headers: { "Content-Type": "application/json" }
      },
    ],
  };

  //turn above data into string
  let jsonData = JSON.stringify(data);

  const url = "https://us9.api.mailchimp.com/3.0/lists/da1ffc6174/members";

  const options = {
    method: "POST",
    auth: "Titus_khalo:17ab03aff2e0743f31bd68c05813ad64-us9",
  };
 const mailchimpRequest =  https.request(url, options, function (response) {
    response.on("data", function (data) {
      console.log(JSON.parse(data));
    });
  });

  request.write(jsonData);
  request.end();
});*/

app.get("/", function (req, res) {
    console.log("suceess")
  res.sendFile(__dirname + "/signup.html");
 
});

//launch to test if server is working
app.listen(3000, function (req, resp) {
  console.log("Server is running on port 3000");
});

//api key 17ab03aff2e0743f31bd68c05813ad64-us9
//list id da1ffc6174
